
!---------------------------------------------------------
	module mod_boxutil
!---------------------------------------------------------

	implicit none

	integer, save :: nvers_box = 0

!---------------------------------------------------------
	contains
!---------------------------------------------------------

!*********************************************************
!*********************************************************
!*********************************************************
! deal with file header
!*********************************************************
!*********************************************************
!*********************************************************

	subroutine read_file_header(iu,ftype)

	implicit none

	integer iu
	integer ftype

	integer i
	integer idbox,nvers
	character*80 string

	character (len=5),dimension(0:8) :: strings = (/
     +		'init ','meteo','2d   ','3d   ',
     +		'     ','     ','     ','geom ','stats'
     +		/)

	read(iu,'(a)') string
	i = index(string,'idbox')

	if( i <= 0 ) then
	  write(6,*) 'old box format... cannot handle'
	  write(6,*) trim(string),i
	  stop 'error stop read_header: old format'
	end if

	read(iu,'(a2,3i10)') string,idbox,ftype,nvers
	if( idbox /= 473226 ) then
	  write(6,*) 'wrong idbox'
	  write(6,*) 'idbox=',idbox,'   expected=473226'
	  stop 'error stop read_header: idbox'
	end if

	if( nvers < 3 .or. nvers > 5 ) then
	  write(6,*) 'wrong nvers'
	  write(6,*) 'nvers=',nvers
	  stop 'error stop read_header: nvers'
	end if

	if( ftype < 0 .or. ftype > 8 ) stop 'error stop: ftype'

	string = strings(ftype)	
	if( string == ' ' ) stop 'no string found'
	write(6,*) 'box file is of type ',ftype,' (',trim(string),')'

	end

!*********************************************************
!*********************************************************
!*********************************************************
! deal with time record
!*********************************************************
!*********************************************************
!*********************************************************

	subroutine read_time_record(iu,dtime,aline,ierr)

	implicit none

	integer iu
	double precision dtime
	character*(*) aline
	integer ierr

	character*80 string

	read(iu,'(a)',end=88,err=99) string
	if( trim(string) /= '# time record' ) then
	  write(6,*) 'error reading time string...'
	  write(6,*) trim(string)
	  stop 'error stop read_time_record: wrong string'
	end if

	read(iu,'(d21.8,a)') dtime,string
	aline = adjustl(string)
	ierr = 0

	return
   99	continue
	write(6,*) 'error reading time string...'
	stop 'error stop read_time_record: generic error'
   88	continue
	ierr = -1
	return
	end

!*********************************************************
!*********************************************************
!*********************************************************
! deal with box data
!*********************************************************
!*********************************************************
!*********************************************************

	subroutine read_box(iu,nbox,nvar,vals)

	implicit none

	integer iu
	integer nbox,nvar
	double precision, allocatable :: vals(:,:)

	call read_box_header(iu,nbox,nvar)
	call alloc_box_arrays(nbox,nvar,vals)
	call read_box_records(iu,nbox,nvar,vals)

	end

!*********************************************************

	subroutine alloc_box_arrays(nbox,nvar,vals)

	implicit none

	integer nbox,nvar
	double precision, allocatable :: vals(:,:)

	logical balloc
	integer n1,n2

	balloc = .false.
	if( .not. allocated(vals) ) then
	  balloc=.true.
	else
	  n1 = size(vals,dim=1)
	  n2 = size(vals,dim=2)
	  if( n1 /= nvar .or. n2 /= nbox ) then
	    deallocate(vals)
	    balloc=.true.
	  end if
	end if

	if( balloc ) then
	  allocate(vals(nvar,nbox))
	end if

	end

!*********************************************************

	subroutine read_box_header(iu,nbox,nvar)

	implicit none

	integer iu
	integer nbox,nvar

	character*80 string

	read(iu,'(a)') string
	if( trim(string) /= '#      boxes       nvars' ) then
	  write(6,*) 'error reading box string...'
	  write(6,*) trim(string)
	  stop 'error stop read_box_header: wrong string'
	end if

	read(iu,*) nbox,nvar

	return
	end

!*********************************************************

	subroutine read_box_records(iu,nbox,nvar,vals)

	implicit none

	integer iu
	integer nbox,nvar
	double precision, allocatable :: vals(:,:)

	logical balloc
	integer i,ib
	character*80 string

	read(iu,'(a)') string
	if( string(1:5) /= '# box' ) then
	  write(6,*) 'error reading box records string...'
	  write(6,*) trim(string)
	  stop 'error stop read_box_records: wrong string'
	end if

	do ib=1,nbox
	  read(iu,*) i,vals(:,ib)
	  if( ib /= i ) goto 99
	end do

	return
   99	continue
	write(6,*) 'error reading box records...'
	write(6,*) i,ib
	  stop 'error stop read_box_records: i/=ib'
	end

!*********************************************************
!*********************************************************
!*********************************************************
! deal with flux data
!*********************************************************
!*********************************************************
!*********************************************************

	subroutine read_flux(iu,nsect,ivals,vals)

	implicit none

	integer iu
	integer nsect
	integer, allocatable :: ivals(:,:)
	double precision, allocatable :: vals(:,:)

	call read_flux_header(iu,nsect)
	call alloc_flux_arrays(nsect,ivals,vals)
	call read_flux_records(iu,nsect,ivals,vals)

	end

!*********************************************************

	subroutine alloc_flux_arrays(nsect,ivals,vals)

	implicit none

	integer nsect
	integer, allocatable :: ivals(:,:)
	double precision, allocatable :: vals(:,:)

	logical balloc
	integer n1,n2

	balloc = .false.
	if( .not. allocated(vals) ) then
	  balloc=.true.
	else
	  n2 = size(vals,dim=2)
	  if( nsect > n2 ) then
	    deallocate(vals)
	    deallocate(ivals)
	    balloc=.true.
	  end if
	end if

	if( balloc ) then
	  allocate(vals(3,nsect))
	  allocate(ivals(2,nsect))
	end if

	end

!*********************************************************

	subroutine read_flux_header(iu,nsect)

	implicit none

	integer iu
	integer nsect

	character*80 string

	read(iu,'(a)') string
	if( trim(string) == '#   sections' ) then
	else if( trim(string) == '#        OBC' ) then
	else
	  write(6,*) 'error reading flux string...'
	  write(6,*) trim(string)
	  stop 'error stop read_flux_header: wrong string'
	end if

	read(iu,*) nsect

	return
	end

!*********************************************************

	subroutine read_flux_records(iu,nsect,ivals,vals)

	implicit none

	integer iu
	integer nsect
	integer, allocatable :: ivals(:,:)
	double precision, allocatable :: vals(:,:)

	logical balloc
	integer i,is
	character*80 string

	read(iu,'(a)') string
	if( string(1:15) /= '# from    to' ) then
	  write(6,*) 'error reading flux records string...'
	  write(6,*) trim(string)
	  stop 'error stop read_flux_records: wrong string'
	end if

	do is=1,nsect
	  read(iu,*) ivals(:,is),vals(:,is)
	end do

	return
   99	continue
	write(6,*) 'error reading flux records...'
	write(6,*) i,is
	  stop 'error stop read_flux_records: i/=ib'
	end

!*********************************************************

!---------------------------------------------------------
	end module mod_boxutil
!---------------------------------------------------------

