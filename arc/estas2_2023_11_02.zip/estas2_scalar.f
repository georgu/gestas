
!------------------------------------------------------------
!
! box model estas2 - scalar variables
!
! administers runs with various scalar variables
! provides common routines advect, mass, output
!
! to add a new module do the following:
!	new logical variable (e.g., bwrt)
!	new calls in scalar_init, scalar_run, scalar_finalize
!
!------------------------------------------------------------

!============================================================
        module boxes_scalar
!============================================================

        implicit none

        integer, save :: irun = 0		!how often called

	logical, save :: bwrt = .true.		!water residence time
	logical, save :: bconz = .false.	!concentrations
	logical, save :: bbfm = .false.		!bfm model
	logical, save :: bsteady = .true.	!steady state
	logical, save :: baqua_bc = .true.	!aquabc model

!============================================================
        end module boxes_scalar
!============================================================

	subroutine scalar_init

! initializes scalar

	use boxes
	use boxes_scalar

	implicit none

	write(6,*) 'initializing scalars'

	if( bwrt ) call wrt_init
	if( bconz ) call conz_init
	if( bbfm ) call bfm_init
	if( bsteady ) call steady_init
	if( baqua_bc ) call aqua_bc_init

	write(6,*) 'finished initializing scalars'

	end
	
!************************************************************

	subroutine scalar_run

! runs scalar

	use boxes
	use boxes_scalar

	implicit none

	irun = irun + 1

	if( bwrt ) call wrt_run
	if( bconz ) call conz_run
	if( bbfm ) call bfm_run
	if( bsteady ) call steady_run
	if( baqua_bc ) call aqua_bc_run

	end
	
!************************************************************

	subroutine scalar_finalize

! finalizes scalar

	use boxes
	use boxes_scalar

	implicit none

	write(6,*) 'the following modules have been run:'

	if( bwrt ) call wrt_finalize
	if( bconz ) call conz_finalize
	if( bbfm ) call bfm_finalize
	if( bsteady ) call steady_finalize
	if( baqua_bc ) call aqua_bc_finalize

	end
	
!************************************************************
!************************************************************
!************************************************************

	subroutine scalar_advect(nscal,iadv,scal,scal_bound)

! advects all scalar variables

	use boxes

	implicit none

	integer nscal
	integer iadv(nscal)
	double precision scal(nbox,nscal)
	double precision scal_bound(-nosect:0,nscal)

	integer is,ib
	double precision time_aux
	double precision s(-nosect:nbox)

	do is=1,nscal
	  if( iadv(is) == 0 ) cycle			!no advection
	  s(1:nbox) = scal(1:nbox,is)
	  s(-nosect:0) = scal_bound(-nosect:0,is)
	  call scalar_advect_single(is,s)
	  scal(1:nbox,is) = s(1:nbox)
	end do

	end

!************************************************************

	subroutine scalar_advect_single(iscal,s)

! advects single scalar variable

	use boxes

	implicit none

	integer iscal
	double precision s(-nosect:nbox)

	logical bdebug
	integer if,it,is,ib
	double precision pos,neg
	double precision mass(-nosect:nbox)

	bdebug = .false.

	mass = 0.
	mass(1:nbox) = vold(1:nbox) * s(1:nbox)

        do is=1,nsect
          if = isect(1,is)      ! box from
          it = isect(2,is)      ! box to
	  pos = dt*flux(2,is)
	  neg = dt*flux(3,is)
          mass(if) = mass(if) + neg*s(it) - pos*s(if)
          mass(it) = mass(it) + pos*s(if) - neg*s(it)
        end do

        do is=1,nosect
          if = iosect(1,is)      ! box from
          it = iosect(2,is)      ! box to
	  pos = dt*oflux(2,is)
	  neg = dt*oflux(3,is)
          mass(if) = mass(if) + neg*s(it) - pos*s(if)
          mass(it) = mass(it) + pos*s(if) - neg*s(it)
        end do

	!if( bpe ) then	!consider precipitation and evaporation
	!  do ib=1,nbox
	!    mass(ib) = mass(ib) 
	!  end do
	!end if

	s(1:nbox) = mass(1:nbox) / vnew(1:nbox)

	end
	
!************************************************************
!************************************************************
!************************************************************

	subroutine scalar_mass_header(iu,nscal,what)

! writes header for mass scalar output

	use boxes

	implicit none

	integer iu,nscal
	character*(*) what

	integer i
	character*80 formhead

	write(iu,'(a,a)') '# ',trim(what)

	formhead = ' '
	write(formhead,'(a,i2,a)') '(a,',nscal,'(a,i2))'

	write(iu,formhead) '#               dtime'
     +		,('         scalar',i,i=1,nscal)

	end

!************************************************************

	subroutine scalar_mass(iu,nscal,scal)

! computes total mass of scalars for check

	use boxes

	implicit none

	integer iu		!unit to write to
	integer nscal
	double precision scal(nbox,nscal)

	integer is,ib
	double precision mass(nscal)
	double precision m

	do is=1,nscal
	  m = 0.
	  do ib=1,nbox
	    m = m + vnew(ib) * scal(ib,is)
	  end do
	  mass(is) = m
	end do

	write(iu,*) dtime,mass

	end
	
!************************************************************

	subroutine scalar_out_header(iu,what)

! writes header for scalar output

	use boxes

	implicit none

	integer iu
	character*(*) what

	integer i
	character*80 formhead

	write(iu,'(a,a)') '# ',trim(what)

	formhead = ' '
	write(formhead,'(a,i2,a)') '(a,',nbox,'(a,i2))'

	write(iu,formhead) '#      date_and_time'
     +		,('   box',i,i=1,nbox)

	end

!************************************************************

	subroutine scalar_out(iubase,nscal,scal)

! outputs scalar

	use boxes

	implicit none

	integer iubase		!base unit to write to
	integer nscal
	double precision scal(nbox,nscal)

	integer is,i,iu
	character*500 line
	character*80 formhead,format

	write(format,'(a,i4,a)') '(a20,',nbox,'f8.2)'

	do is=1,nscal
	  iu = iubase + is
	  write(iu,format) stime,scal(:,is)
	end do

	end
	
!************************************************************

