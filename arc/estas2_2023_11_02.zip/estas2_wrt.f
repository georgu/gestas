
!------------------------------------------------------------
!
! box model estas2 - WRT (water residence time) computations
!
! this simulates the water residence time and age of the water
!
!	scal(:,1)	WRT
!	scal(:,2)	confinement
!	scal(:,3)	age
!
!------------------------------------------------------------

!============================================================
        module boxes_wrt
!============================================================

        implicit none

        integer, parameter :: nscal = 3		!total number of scalars

        integer, save :: iubase = 20		!unit for output

	double precision, save :: dtwrt = 90	!reset time for WRT (in days)

	integer, save :: iadv(nscal) = 1	!advection of scalars

!	-----------------------------------------------------

	integer, save :: ifrqwrt = 0
	integer, save :: iacc = 0

	double precision, save :: dtime_reset = 0
	double precision, save :: tacu = 0
	double precision, save, allocatable :: wrtacc(:,:)
	double precision, save, allocatable :: wrtlog(:,:)

	double precision, parameter :: spd = 86400	!seconds per day

	double precision, save, allocatable :: scal(:,:) !scalar variables
	double precision, save, allocatable :: scal_bound(:,:)	!scalar BC

!============================================================
        end module boxes_wrt
!============================================================

!************************************************************

	subroutine wrt_run

! runs wrt routines

	use boxes
	use boxes_wrt

	implicit none

	call wrt_boundary_condition
	call scalar_advect(nscal,iadv,scal,scal_bound)
	call wrt_react
	call scalar_mass(iubase,nscal,scal)
	call scalar_out(iubase,nscal,scal)

	end
	
!************************************************************

	subroutine wrt_finalize

! finalizes WRT module

	write(6,*) 'water residence time (WRT) module has been run'

	end

!************************************************************

	subroutine wrt_init

! initializes scalar for WRT computations

	use boxes
	use boxes_wrt

	implicit none

	integer iu

	if( nscal /= 3 ) then
	  stop 'error stop wrt_init: nscal /= 3'
	end if

	if( nbound < 0 ) then
	  write(6,*) 'nbound = ',nbound
	  write(6,*) 'number of open boundary conditions not initialized'
	  stop 'error stop wrt_init: nbound'
	end if

	allocate(scal(nbox,nscal))
	allocate(scal_bound(-nbound:0,nscal))
	scal = 0.
	scal_bound = 0.

	allocate(wrtacc(nbox,nscal))
	allocate(wrtlog(nbox,nscal))

	call wrt_reset

	ifrqwrt = nint( spd * dtwrt / dt )	!frequency of reset

	iu = iubase
	call scalar_mass_header(iu,nscal,'total mass for scalars')

	iu = iubase
	call scalar_out_header(iu+1,'concentration for WRT')
	call scalar_out_header(iu+2,'concentration for confinement')
	call scalar_out_header(iu+3,'water age')

	iu = iubase + 3
	call scalar_out_header(iu+1,'WRT (integration)')
	call scalar_out_header(iu+2,'confinement (integration)')
	call scalar_out_header(iu+3,'water age (snap shot)')

	iu = iubase + 6
	call scalar_out_header(iu+1,'WRT (log)')
	call scalar_out_header(iu+2,'confinement (log)')
	call scalar_out_header(iu+3,'water age (snap shot)')

	write(6,*) 'finished initializing wrt: ',nscal,ifrqwrt

	end
	
!************************************************************

	subroutine wrt_reset

! resets scalar for WRT computations

	use boxes
	use boxes_wrt

	implicit none

	dtime_reset = dtime
	tacu = 0.

	iacc = 0
	wrtacc = 0.
	wrtlog = 0.
	scal(:,1) = 1.
	scal(:,2) = 0.

	end

!************************************************************

	subroutine wrt_boundary_condition

! sets boundary conditions for WRT - open boundary is 1

	use boxes
	use boxes_wrt

	implicit none

	scal_bound = 0.
	scal_bound(-1,2) = 1.		!OBC for confinement

	end
	
!************************************************************

	subroutine wrt_react

! does computations for WRT

	use boxes
	use boxes_wrt

	implicit none

	integer iu
	double precision time
	double precision rl(nbox)
	character*80 format

	iacc = iacc + 1

	time = dtime - dtime_reset
	tacu = tacu + time*time

	rl = -log(scal(:,1))
	wrtlog(:,1) = wrtlog(:,1) + rl*time
	rl = -log(1.-scal(:,2))
	wrtlog(:,2) = wrtlog(:,2) + rl*time

	wrtacc(:,1) = wrtacc(:,1) + dt*scal(:,1)		!WRT
	wrtacc(:,2) = wrtacc(:,2) + dt*(1.-scal(:,2))		!confinement
	scal(:,3) = scal(:,3) + dt / spd			!age

	if( iacc == ifrqwrt ) then
	  write(format,'(a,i4,a)') '(a20,',nbox,'f8.2)'
	  scal(:,1) = wrtacc(:,1) / spd
	  scal(:,2) = wrtacc(:,2) / spd
	  iu = iubase + 3
	  write(iu+1,format) stime,scal(:,1)
	  write(iu+2,format) stime,scal(:,2)
	  write(iu+3,format) stime,scal(:,3)
	  scal(:,1) = (tacu/wrtlog(:,1)) / spd
	  scal(:,2) = (tacu/wrtlog(:,2)) / spd
	  iu = iubase + 6
	  write(iu+1,format) stime,scal(:,1)
	  write(iu+2,format) stime,scal(:,2)
	  write(iu+3,format) stime,scal(:,3)
	  call wrt_reset	!resets all vars, also iacc
	end if

	end

!************************************************************

