
!***************************************************************
!
! boxinf - routine to check one and compare two box files
!
!***************************************************************

	module mod_boxinf

	logical, save :: bsilent = .false.
	logical, save :: bquiet = .false.
	logical, save :: bnodiff = .false.
	logical, save :: bverbose = .false.
	logical, save :: bnostop = .false.
	logical, save :: bstop = .true.
	double precision, save :: maxdiff = 0.

	double precision, save :: dstart,dend,dt
	character*20, save :: astart,aend

	end module mod_boxinf

!***************************************************************

	program boxinf

	use clo
	use mod_boxinf

	implicit none

	integer nc,ierr

	call boxinf_init

        nc = clo_number_of_files()

        if( nc == 0 ) then
          call clo_usage
        else if( nc == 1 ) then
          call read_box_file
        else if( nc == 2 ) then
          call compare_box_files(ierr)
        else
          write(6,*) 'nc = ',nc
          stop 'error stop boxinf: wrong number of files'
        end if

        if( ierr > 0 ) then
          if( ierr == 99 ) ierr = 100   !terrible hack - FIXME
          call exit(ierr)
        else
          call exit(99)
        end if

	end

!***************************************************************

	subroutine read_box_file

	use mod_boxinf
	use mod_boxutil
	use clo

	implicit none

	logical bwrite				!write single time records
	logical b2d,bmeteo
	double precision dtime
	double precision rain,evap,period,dyear
	integer nbox,ibox,ftype,i,iu,nvar,nsect
	integer ios,ierr,nrec,nvals,ival
	character*20 aline
	character*80 sh,format,format77
	character*80 name_one

	double precision, allocatable :: acum(:,:),aver(:)
	double precision, allocatable :: boxvals(:,:)
	double precision, allocatable :: sectvals(:,:)
	double precision, allocatable :: obcvals(:,:)
	integer, allocatable :: isvals(:,:)
	integer, allocatable :: iovals(:,:)

	bwrite = bverbose
	nrec = 0
	ierr = 0
	dt = 0.

!--------------------------------------------------------------
! open file
!--------------------------------------------------------------

        call clo_get_file(1,name_one)

	iu = 1
	open(iu,file=name_one,status='old',form='formatted',iostat=ios)

        if( ios /= 0 ) then
	  write(6,*) 'cannot open file: ',trim(name_one)
	  stop 'error opening file'
	end if

!--------------------------------------------------------------
! check file type
!--------------------------------------------------------------

	call read_file_header(iu,ftype)
	b2d = ( ftype == 2 )
	bmeteo = ( ftype == 1 )
	if( b2d .or. bmeteo ) then
	  !ok
	else
	  stop 'error stop: ftype/=[12]'
	end if
	call make_formats(ftype,sh,format,format77)

!--------------------------------------------------------------
! time loop
!--------------------------------------------------------------

	do
	  call read_time_record(iu,dtime,aline,ierr)
	  if( ierr /= 0 ) exit

	  call handle_time(nrec,dtime,aline)

	  call read_box(iu,nbox,nvar,boxvals)
	  if( b2d ) then
	    call read_flux(iu,nsect,isvals,sectvals)
	    call read_flux(iu,nsect,iovals,obcvals)
	  end if

	  if( nrec == 1 ) then
	    allocate(acum(nvar,nbox),aver(nvar))
	    acum = 0.
	  end if
	  acum(:,:) = acum(:,:) + boxvals(:,:)
	  do ival=1,nvar
	    aver(ival) = sum(boxvals(ival,:)) / nbox
	  end do

	  write(77,format77) aline,aver
	  if( bwrite ) write(6,*) 'time = ',aline,dtime
	end do

!--------------------------------------------------------------
! end of time loop
!--------------------------------------------------------------

	if( ierr > 0 ) stop 'error stop: read error'

	write(6,*) 'final message:'
	write(6,*) 'boxes:        ',nbox
	write(6,*) 'records read: ',nrec
	write(6,*) 'values read:  ',nvar
	write(6,*) 'start date of simulation:  ',astart
	write(6,*) 'end date of simulation:    ',aend
	write(6,*) 'time step:    ',dt

	acum = acum / nrec
	do ival=1,nvar
	  aver(ival) = sum(acum(ival,:)) / nbox
	end do
	write(6,*) 'time average of box values:'
	write(6,'(a)') trim(sh)
	write(6,format) aver

	if( bmeteo ) call compute_rain(aver)

!--------------------------------------------------------------
! end of routine
!--------------------------------------------------------------

	end

!***************************************************************

	subroutine compare_box_files(ierr)

	use mod_boxinf
	use mod_boxutil
	use clo

	implicit none

	integer ierr

	logical bwrite				!write single time records
	logical b2d,bmeteo
	double precision dtime,dtime1,dtime2
	double precision verr,verr1,verr2,verrmax
	integer ibox,i,iu1,iu2
	integer i1,i2
	integer ftype,ftype1,ftype2
	integer nbox,nbox1,nbox2
	integer nvar,nvar1,nvar2
	integer nsect,nsect1,nsect2
	integer ios,nrec,ival
	character*20 aline
	character*80 sh,format,format77
	character*80 name_one,name_two

	double precision, allocatable :: boxvals1(:,:),boxvals2(:,:)
	double precision, allocatable :: sectvals1(:,:),sectvals2(:,:)
	integer, allocatable :: ivals1(:,:),ivals2(:,:)

	bwrite = bverbose
	nrec = 0
	ierr = 0
	dt = 0.

!--------------------------------------------------------------
! open files
!--------------------------------------------------------------

        call clo_get_file(1,name_one)
        call clo_get_file(2,name_two)

	iu1 = 1
	open(iu1,file=name_one,status='old',form='formatted',iostat=ios)

        if( ios /= 0 ) then
	  write(6,*) 'cannot open file: ',trim(name_one)
	  stop 'error opening file'
	end if

	iu2 = 2
	open(iu2,file=name_two,status='old',form='formatted',iostat=ios)

        if( ios /= 0 ) then
	  write(6,*) 'cannot open file: ',trim(name_two)
	  stop 'error opening file'
	end if

!--------------------------------------------------------------
! check file types
!--------------------------------------------------------------

	call read_file_header(iu1,ftype1)
	call read_file_header(iu2,ftype2)
	if( ftype1 /= ftype2 ) stop 'error stop: ftype1/=ftype2'
	ftype = ftype1
	b2d = ( ftype == 2 )
	bmeteo = ( ftype == 1 )
	if( b2d .or. bmeteo ) then
	  !ok
	else
	  stop 'error stop: ftype/=[12]'
	end if
	call make_formats(ftype,sh,format,format77)

!--------------------------------------------------------------
! time loop
!--------------------------------------------------------------

	do
	  call read_time_record(iu1,dtime1,aline,ierr)
	  if( ierr /= 0 ) exit
	  call read_time_record(iu2,dtime2,aline,ierr)
	  if( ierr /= 0 ) exit
	  if( dtime1 /= dtime2 ) stop 'error stop: dtime1/=dtime2'

	  call handle_time(nrec,dtime,aline)

	  call read_box(iu1,nbox1,nvar1,boxvals1)
	  call read_box(iu2,nbox2,nvar2,boxvals2)
	  if( nbox1 /= nbox2 ) stop 'error stop: nbox1/=nbox2'
	  if( nvar1 /= nvar2 ) stop 'error stop: nvar1/=nvar2'
	  nbox = nbox1
	  nvar = nvar1

	  call compare_values('box',nvar,nbox,boxvals1,boxvals2,verr)
	  verrmax = max(verrmax,verr)

	  if( b2d ) then
	    call read_flux(iu1,nsect1,ivals1,sectvals1)
	    call read_flux(iu2,nsect2,ivals2,sectvals2)
	    if( nsect1 /= nsect2 ) stop 'error stop: nsect1/=nsect2'
	    nsect = nsect1
	    call compare_values('flux',3,nsect,sectvals1,sectvals2,verr1)
	    verrmax = max(verrmax,verr1)
	    call read_flux(iu1,nsect1,ivals1,sectvals1)
	    call read_flux(iu2,nsect2,ivals2,sectvals2)
	    if( nsect1 /= nsect2 ) stop 'error stop: nsect1/=nsect2'
	    nsect = nsect1
	    call compare_values('flux',3,nsect,sectvals1,sectvals2,verr2)
	    verrmax = max(verrmax,verr2)
	  end if

	  if( bwrite ) write(6,1000) aline,verr,verr1,verr2
 1000	  format(a,3g16.8)
	end do

!--------------------------------------------------------------
! end of time loop
!--------------------------------------------------------------

	if( ierr > 0 ) stop 'error stop: read error'

	write(6,*) 'final message:'
	write(6,*) 'boxes:        ',nbox
	write(6,*) 'records read: ',nrec
	write(6,*) 'values read:  ',nvar
	write(6,*) 'start date of simulation:  ',astart
	write(6,*) 'end date of simulation:    ',aend
	write(6,*) 'time step:    ',dt
	write(6,*) 'maximum difference:    ',verrmax

!--------------------------------------------------------------
! end of routine
!--------------------------------------------------------------

	end

!*****************************************************

	subroutine compare_values(type,n1,n2,vals1,vals2,verr)

	implicit none

	character*(*) type
	integer n1,n2
	double precision vals1(n1,n2)
	double precision vals2(n1,n2)
	double precision verr

	integer i1,i2
	double precision atot,diff,aux

	verr = 0.

	if( type == 'box' ) then
	  do i2=1,n2
	    do i1=1,n1
	      diff = abs( vals1(i1,i2) - vals2(i1,i2) )
	      atot = abs(vals1(i1,i2)) + abs(vals2(i1,i2))
	      if( diff > 0 .and. atot > 0. ) then
	        aux = 2.*diff/atot
	        verr = max(verr,aux)
	      end if
	    end do
	  end do
	else if( type == 'flux' ) then
	  do i2=1,n2
	    do i1=1,n1
	      diff = abs( vals1(i1,i2) - vals2(i1,i2) )
	      atot = abs(vals1(i1,i2)) + abs(vals2(i1,i2))
	      if( diff > 0 .and. atot > 0. ) then
	        aux = 2.*diff/atot
	        verr = max(verr,aux)
	      end if
	    end do
	  end do
	else
	  stop 'error stop compare_values: unknown type'
	end if
	
	end

!*****************************************************

	subroutine handle_time(nrec,dtime,aline)

	use mod_boxinf

	implicit none

	integer nrec
	double precision dtime
	character*(*) aline

	if( nrec == 0 ) then
	  dstart = dtime
	  astart = aline
	else if( nrec == 1 ) then
	  dt = dtime - dstart
	else
	  if( dt /= dtime - dend ) then
	    write(6,*) 'changing time step: ',dt,dtime-dend
	    stop 'error stop: time step'
	  end if
	end if

	dend = dtime
	aend = aline

	nrec = nrec + 1

	end

!*****************************************************

	subroutine compute_rain(vals)

	implicit none

	double precision vals(*)	!averaged values

	double precision, parameter :: dyear = 365.25
	double precision :: rain,evap

	rain = vals(6) * dyear		!converts from mm/day to mm/year
	evap = vals(7) * dyear
	write(6,*) 'average rain per year [mm]: ',rain
	write(6,*) 'average evap per year [mm]: ',evap

	end
	
!*****************************************************

	subroutine make_formats(ftype,sh,format,format77)

	implicit none

	integer ftype
	character*80 sh,format,format77

	if( ftype == 0 ) then
          sh = '  init_eta'
	  format   = '(    f10.3)'
	  format77 = '(a20,f10.3)'
	else if( ftype == 1 ) then
          sh = '    srad    tair    rhum  wspeed'
     +		 // '     cc   rain   evap    ice'
	  format   = '(    4f8.3,4f7.3)'
	  format77 = '(a20,4f8.3,4f7.3)'
	else if( ftype == 2 ) then
          sh = '     temp     salt  c_speed  act_eta'
     +		 // ' aver_eta  bstress      volume'
	  format   = '(    6f9.3,1e12.4)'
	  format77 = '(a20,6f8.3,1e12.4)'
	else if( ftype == 7 ) then
          sh = '        area   depth'
	  format   = '(    e12.4,f8.3)'
	  format77 = '(a20,e12.4,f8.3)'
	else if( ftype == 8 ) then
          sh = '   layers        area      volume    depth'
	  format   = '(    1f9.3,2e12.4,1f9.3)'
	  format77 = '(a20,1f9.3,2e12.4,1f9.3)'
	else
	  write(6,*) 'cannot handle this file type: ',ftype
	  stop 'error stop make_formats: ftype not supported'
	end if

	end

!*****************************************************

        subroutine boxinf_init

        use mod_boxinf
        use clo

        implicit none

        logical baux
        character*80 version

        version = '1.0'

        call clo_init('boxinf','box-file(s)',trim(version))

        call clo_add_info('checks box files')

        call clo_add_sep('general options:')
        call clo_add_option('silent',.false.,'be silent')
        call clo_add_option('quiet',.false.,'be quiet')
        call clo_add_option('nodiff',.false.,'do not show differences')
        call clo_add_option('verbose',.false.,'be verbose')
        call clo_add_option('nostop',.false.,'do not stop at error')
        call clo_add_option('maxdiff',0.,'maximum tolerated difference')

        call clo_parse_options

        call clo_get_option('silent',bsilent)
        call clo_get_option('quiet',bquiet)
        call clo_get_option('nodiff',bnodiff)
        call clo_get_option('verbose',bverbose)
        call clo_get_option('nostop',baux)
        call clo_get_option('maxdiff',maxdiff)

        if( baux ) bstop = .false.
        if( bsilent ) bquiet = .true.
        if( bquiet ) bverbose = .false.

        end

!*****************************************************

